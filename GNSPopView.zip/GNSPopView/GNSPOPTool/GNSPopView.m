//
//  GNSPopView.m
//  mansory
//
//  Created by Lyn on 2017/6/7.
//  Copyright © 2017年 Lyn. All rights reserved.
//

#import "GNSPopView.h"

#define kDefaultBtnBackgroundColor kCOLOR(155, 255, 255)
#define kDefaultBtnTitleWhiteColor [UIColor whiteColor]
#define kDefaultShadowgroundColor  kCOLOR(155, 155, 155);

#define kDefaultBtnFont 14
#define kDefaultTableViewHeight 44

@interface GNSPopView ()<UITextViewDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, weak  ) UIWindow      *keyWindow; /// 当前窗口
@property (nonatomic, strong) UIView        *shadowView; /// 遮罩层
@property (nonatomic, weak  ) UITapGestureRecognizer *tapGesture; ///背景的手势
@property (assign, nonatomic) popViewType   popViewType;//类型
@property (strong, nonatomic) UIView        *popView;

/*textView*/
@property (assign, nonatomic) BOOL          popViewCanHide;
@property (strong, nonatomic) UITextView    *textView;
@property (strong, nonatomic) UIButton      *textSureBtn;

/*tableviewPopView*/
@property (strong,nonatomic ) UITableView   *tableView;

/*alertView*/
@property (strong, nonatomic) UILabel       *alertLabel;

/*popviewFrame*/
@property (assign,nonatomic ) CGRect        selfFrame;


@end

@implementation GNSPopView
@synthesize popViewDelegate;

- (instancetype)initWithFrame:(CGRect)frame WithType:(popViewType)popViewType {
    
    if (!(self = [super initWithFrame:[UIApplication sharedApplication].keyWindow.bounds])) return nil;
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    //    self.alpha = 0.f;
    //    self.transform = CGAffineTransformMakeScale(0.01f, 0.01f);
    if(frame.size.height <88) {
        frame.size.height = 88;
        _selfFrame = frame;
    }else {
        _selfFrame = frame;
    }
    _shadowViewBackgroundColor = kDefaultBtnBackgroundColor;
    _popViewType = popViewType;
    
    if(popViewType == textViewPopView) {
        _textSureBtnTitle = @"确认";
        _textSureBtnColor = kDefaultBtnBackgroundColor;
        _textSureBtnTitleColor = kDefaultBtnTitleWhiteColor;
        _textViewFont = [UIFont systemFontOfSize:14];
    }else if(popViewType == alertPopView) {
        _alertLabelFont = [UIFont systemFontOfSize:14];
        _alertLabelText = @"You need setAlertLabelText";
        _alertLabelColor = [UIColor blackColor];
        _alertLabelBtnColor = @[kDefaultBtnBackgroundColor];
        _alertLabelBtnTitle = @[@"确认"];
        _alertLabelBtnTitleColor = @[kDefaultBtnTitleWhiteColor];
    }else if(popViewType == tableViewPopView) {
        _tableDataArray = @[@"You need setTableDataArray",@"设置dataArray"];
    }
    [self initUI];
    [self initPopView];
    [self addSubview:self.popView];
    
    return self;
}

- (void)initUI {
    self.backgroundColor = [UIColor clearColor];
    
    // keyWindow
    _keyWindow = [UIApplication sharedApplication].keyWindow;
    // shadeView
    _shadowView = [[UIView alloc] initWithFrame:_keyWindow.bounds];
    _shadowView.alpha = 0.0;
    _shadowView.backgroundColor = kDefaultShadowgroundColor;
    
    [self addSubview:_shadowView];
    [self setShowShade:YES];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidenPopView)];
    [_shadowView addGestureRecognizer:tapGesture];
    _tapGesture = tapGesture;
}

- (void)initPopView{
    if(self.popView != nil) {
        self.popView = nil;
    }
    self.popView = [[UIView alloc] init];
    self.popView.backgroundColor = [UIColor whiteColor];
    self.popView.layer.masksToBounds = YES;
    self.popView.layer.cornerRadius = 8;
    
    if(self.popViewType == tableViewPopView) {
        [self createTableViewPopView];
        
    }else if(self.popViewType == alertPopView) {
        [self createAlertPopView];
        
    }else if(self.popViewType == textViewPopView) {
        [self createTextPopView];
    }
}

- (void)createTableViewPopView {
    self.popView.frame = CGRectMake(self.selfFrame.origin.x, self.selfFrame.origin.y, self.selfFrame.size.width, self.selfFrame.size.height);
    [self.popView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.popView.frame.size.width, self.popView.frame.size.height)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.popView addSubview:self.tableView];
}

#pragma mark - tableView delegate;
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_tableDataArray count];
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kDefaultTableViewHeight;
}

#pragma mark - you can use your own cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *TableSampleIdentifier = @"TableSampleIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableSampleIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:TableSampleIdentifier];
    } else {
        while ([cell.contentView.subviews lastObject ]!=nil) {
            [(UIView*)[cell.contentView.subviews lastObject]removeFromSuperview];
        }
    }
    cell.textLabel.text= _tableDataArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.popViewDelegate popTableViewDidSelect:indexPath];
    [self hidenPopView];
    
}

#pragma mark - createAlertPopView
- (void)createAlertPopView {
    
    self.popView.frame = CGRectMake(self.selfFrame.origin.x, self.selfFrame.origin.y, self.selfFrame.size.width, self.selfFrame.size.height);
    [self.popView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    self.alertLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, self.selfFrame.size.width - 16,self.selfFrame.size.height-44)];
    
    [self.popView addSubview:self.alertLabel];
    self.alertLabel.text = _alertLabelText;
    self.alertLabel.font = _alertLabelFont;
    self.alertLabel.textColor = _alertLabelColor;
    self.alertLabel.numberOfLines = 0;
    
    [self.alertLabel sizeToFit];
    if(self.popViewType == alertPopView) {
        self.popView.frame = CGRectMake(self.selfFrame.origin.x, self.selfFrame.origin.y, self.selfFrame.size.width, CGRectGetMaxY(self.alertLabel.frame)+44);
    }
    
    CGFloat btnWidth = (self.selfFrame.size.width-16 - 8*(_alertLabelBtnTitle.count-1))/_alertLabelBtnTitle.count;
    for (int i = 0 ; i<_alertLabelBtnTitle.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(8+(btnWidth+8)*i, self.popView.frame.size.height-36, btnWidth, 28)];
        [self.popView addSubview:btn];
        [btn setTitle:_alertLabelBtnTitle[i] forState:UIControlStateNormal];
        [btn setTitleColor:_alertLabelBtnTitleColor[i] forState:UIControlStateNormal];
        [btn setBackgroundColor:_alertLabelBtnColor[i]];
        btn.layer.masksToBounds = YES;
        btn.layer.cornerRadius = 8;
        btn.tag = i;
        btn.titleLabel.font =[UIFont systemFontOfSize:kDefaultBtnFont];
        [btn addTarget:self action:@selector(alertBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
}
- (void)createTextPopView {
    UIButton *textBackViewBtn = [[UIButton alloc] initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    [self addSubview:textBackViewBtn];
    [textBackViewBtn addTarget:self action:@selector(textEndEdit) forControlEvents:UIControlEventTouchUpInside];
    
    self.popView.frame = CGRectMake(self.selfFrame.origin.x, self.selfFrame.origin.y, self.selfFrame.size.width, self.selfFrame.size.height-44);
    _textView = [[UITextView alloc] initWithFrame:CGRectMake(8, 8, self.selfFrame.size.width-16, self.selfFrame.size.height-44-8)];
    _textView.delegate = self;
    _textView.font = _textViewFont;
    
    _textSureBtn = [[UIButton alloc] initWithFrame:CGRectMake(12, self.selfFrame.size.height-36, self.selfFrame.size.width-24, 28)];
    _textSureBtn.backgroundColor = _textSureBtnColor;
    _textSureBtn.layer.masksToBounds = YES;
    _textSureBtn.layer.cornerRadius = 8;
    _textSureBtn.titleLabel.font = [UIFont systemFontOfSize:kDefaultBtnFont];
    [_textSureBtn setTitle:_textSureBtnTitle forState:UIControlStateNormal];
    [_textSureBtn setTitleColor:_textSureBtnTitleColor forState:UIControlStateNormal];
    [_textSureBtn addTarget:self action:@selector(textFinish) forControlEvents:UIControlEventTouchUpInside];
    [_textView becomeFirstResponder];
    [self.popView addSubview:_textSureBtn];
    [self.popView addSubview:_textView];
}
#pragma mark - textSureBtnClick 确认按钮点击事件
- (void)alertBtnClick:(UIButton *)sender {
    [self.popViewDelegate alertBtnClick:sender];
    [self hidenPopView];
}
- (void)textFinish {
    [self.popViewDelegate textViewBtnClick:_textView.text];
    [self hidenPopView];
}
#pragma mark - textField 代理
- (void)textEndEdit {
    if(self.textView.text.length == 0) {
        [self hidenPopView];
    }else {
        if(_popViewCanHide == NO) {
            [self endEditing:YES];
            _popViewCanHide = YES;
        }else {
            [self hidenPopView];
        }
    }
}
#pragma mark - textfield delegate
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self endEditing:YES];
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    _popViewCanHide = NO;
}

- (void)textViewDidChange:(UITextView *)textView {
    if(textView.text.length >0) {
        
        [UIView animateWithDuration:0.5 animations:^{
            self.popView.frame = self.selfFrame;
        }];
    }else {
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect frame = self.popView.frame;
            frame.size.height =  frame.size.height - 44;
            self.popView.frame = frame;
        }];
    }
}

#pragma mark - showpopView 显示popView
/*弹出*/
- (void)showPopView {
    
    self.popView.frame = CGRectMake(_showPoint.x, _showPoint.y, self.popView.frame.size.width, self.popView.frame.size.height);
    
    [UIView animateWithDuration:0.5 animations:^{
        _shadowView.alpha = 0.7f;
        self.popView.frame = CGRectMake(_selfFrame.origin.x , _selfFrame.origin.y, self.popView.frame.size.width, self.popView.frame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - hidePopView 隐藏popView
/*隐藏*/
- (void)hidenPopView {
    
    [UIView animateWithDuration:0.5 animations:^{
        self.alpha = 0.f;
        _shadowView.alpha = 0.f;
        self.popView.transform = CGAffineTransformMakeScale(0.01f, 0.01f);
    } completion:^(BOOL finished) {
        [_shadowView removeFromSuperview];
        [self removeFromSuperview];
    }];
    
}

#pragma mark - 是否展示shadowView
- (void)setShowShade:(BOOL)set {
    if(set) {
        self.shadowView.hidden = NO;
    }else {
        self.shadowView.hidden = YES;
    }
};

#pragma mark - 属性 set方法
- (void)setShadeViewHidden:(BOOL)shadeViewHidden {
    _shadeViewHidden = shadeViewHidden;
    [self setShowShade:!_shadeViewHidden];
}

- (void)setShadowViewBackgroundColor:(UIColor *)shadowViewBackgroundColor {
    shadowViewBackgroundColor = shadowViewBackgroundColor;
    self.shadowView.backgroundColor = shadowViewBackgroundColor;
    if(self.shadowView.hidden == YES) {
        DLog(@"=================shadeView.hidden == YES:Setting backgroundColor isn't useful===================");
    };
}

- (void)setTextSureBtnTitle:(NSString *)textSureBtnTitle {
    _textSureBtnTitle = textSureBtnTitle;
    [_textSureBtn setTitle:textSureBtnTitle forState:UIControlStateNormal];
    if(self.popViewType != textViewPopView) {
        DLog(@"=================theType isnt textViewPopView  you dont need textSureBtnTitle==========");
    }
}

- (void)setTextSureBtnTitleColor:(UIColor *)textSureBtnTitleColor {
    _textSureBtnTitleColor = textSureBtnTitleColor;
    [_textSureBtn setTitleColor:textSureBtnTitleColor forState:UIControlStateNormal];
    if(self.popViewType != textViewPopView) {
        DLog(@"=================theType isnt textViewPopView  you dont need textSureBtnTitleColor==========");
    }
}

- (void)setTextViewFont:(UIFont *)textViewFont {
    _textViewFont = textViewFont;
    _textView.font = _textViewFont;
    if(self.popViewType != textViewPopView) {
        DLog(@"=================theType isnt textViewPopView  you dont need textViewFont==========");
    }
}

- (void)setAlertLabelBtnTitle:(NSArray *)alertLabelBtnTitle {
    _alertLabelBtnTitle = alertLabelBtnTitle;
    
    if(_alertLabelBtnColor.count < _alertLabelBtnTitle.count) {
        NSMutableArray *mid = [_alertLabelBtnColor mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnTitle.count - _alertLabelBtnColor.count); i++) {
            [mid addObject:kDefaultBtnBackgroundColor];
        }
        _alertLabelBtnColor = mid;
        DLog(@"========You should set alertLabelBtnColor============");
    }
    if(_alertLabelBtnTitleColor.count < _alertLabelBtnTitle.count) {
        NSMutableArray *mid = [_alertLabelBtnTitleColor mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnTitle.count - _alertLabelBtnTitleColor.count); i++) {
            [mid addObject:kDefaultBtnTitleWhiteColor];
        }
        _alertLabelBtnTitleColor = mid;
        DLog(@"=============You should set alertLabelBtnTitleColor============");

    }
    
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnTitle==========");
    }
}

- (void)setAlertLabelBtnTitleColor:(NSArray *)alertLabelBtnTitleColor {
    _alertLabelBtnTitleColor = alertLabelBtnTitleColor;
    if(_alertLabelBtnTitle.count < _alertLabelBtnTitleColor.count) {
        NSMutableArray *mid = [_alertLabelBtnTitle mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnTitleColor.count - _alertLabelBtnTitle.count); i++) {
            [mid addObject:@"确认"];
        }
        _alertLabelBtnTitle = mid;
    }
    if(_alertLabelBtnColor.count < _alertLabelBtnTitleColor.count) {
        NSMutableArray *mid = [_alertLabelBtnColor mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnTitleColor.count - _alertLabelBtnColor.count); i++) {
            [mid addObject:kDefaultBtnBackgroundColor];
        }
        _alertLabelBtnColor = mid;
    }
    
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnTitleColor==========");
    }
}

- (void)setAlertLabelBtnColor:(NSArray *)alertLabelBtnColor {
    _alertLabelBtnColor = alertLabelBtnColor;
    if(_alertLabelBtnTitle.count < _alertLabelBtnColor.count) {
        NSMutableArray *mid = [_alertLabelBtnTitle mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnColor.count - _alertLabelBtnTitle.count); i++) {
            [mid addObject:@"确认"];
        }
        _alertLabelBtnTitle = mid;
    }
    if(_alertLabelBtnTitleColor.count < _alertLabelBtnColor.count) {
        NSMutableArray *mid = [_alertLabelBtnTitleColor mutableCopy];
        for ( int i = 0; i<(int)(_alertLabelBtnColor.count - _alertLabelBtnTitleColor.count); i++) {
            [mid addObject:[UIColor whiteColor]];
        }
        _alertLabelBtnTitleColor = mid;
    }
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnColor==========");
    }
}

/* self.alertLabel.text = _alertLabelText;
 self.alertLabel.font = _alertLabelFont;
 self.alertLabel.textColor = _alertLabelColor;
*/
- (void)setAlertLabelText:(NSString *)alertLabelText {
    _alertLabelText = alertLabelText;
    self.alertLabel.text = _alertLabelText;
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnColor==========");
    }
}

- (void)setAlertLabelFont:(UIFont *)alertLabelFont {
    _alertLabelFont = alertLabelFont;
     self.alertLabel.font = _alertLabelFont;
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnColor==========");
    }
}

- (void)setAlertLabelColor:(UIColor *)alertLabelColor {
    _alertLabelColor = alertLabelColor ;
    self.alertLabel.textColor = _alertLabelColor;
    if(self.popViewType == alertPopView) {
        [self createAlertPopView];
    }else {
        DLog(@"=================theType isnt alertPopView  you dont need alertLabelBtnColor==========");
    }
}

- (void)setTableDataArray:(NSArray *)tableDataArray {
    _tableDataArray = tableDataArray;
    [self.tableView reloadData];
}

@end
