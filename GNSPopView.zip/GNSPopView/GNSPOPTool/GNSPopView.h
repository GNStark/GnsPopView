//
//  GNSPopView.h
//  mansory
//
//  Created by Lyn on 2017/6/7.
//  Copyright © 2017年 Lyn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GnsPopDefine.h"
typedef enum : NSUInteger{
    tableViewPopView ,
    alertPopView ,
    textViewPopView
} popViewType;

@protocol GNSPopViewDelegate

- (void)textViewBtnClick:(NSString *)text;
/*
 You can get btn.tag title or other thing;
 */
- (void)alertBtnClick:(UIButton*)btn;

- (void)popTableViewDidSelect :(NSIndexPath *)index;

@end

@interface GNSPopView : UIView 

@property (assign,nonatomic)id< GNSPopViewDelegate > popViewDelegate;
#pragma mark - ===================init===================
/*初始化方法*/
- (instancetype)initWithFrame:(CGRect)frame WithType:(popViewType)popViewType ;

#pragma mark - ===================UI====================
/*遮罩层背景色*/
@property (strong,nonatomic) UIColor *shadowViewBackgroundColor; //defult 155,155,155
/*遮罩层是否显示*/
@property (assign,nonatomic) BOOL shadeViewHidden; //defult show
#pragma mark - ======================tableViewPopView======================
//tableView dataSource
@property (nonatomic,strong) NSArray *tableDataArray;

#pragma mark - ======================textViewPopView====================
/*
 if popViewType is textViewPopView
 */
/*输入框字体大小*/
@property (strong,nonatomic) UIFont *textViewFont; //default  14
/*确认按钮颜色*/
@property (strong,nonatomic) UIColor *textSureBtnColor;  //default kCOLOR(151, 255, 255);
/*确认颜色标题*/
@property (strong,nonatomic) NSString *textSureBtnTitle;//default @"确认";
/*确认按钮标题颜色*/
@property (strong,nonatomic) UIColor *textSureBtnTitleColor; //defult whiteColor


#pragma mark - ======================alertViewPopView======================
/*
 if popViewType is alertViewPopView
 */
/*显示文字*/
@property (strong,nonatomic) NSString *alertLabelText; //default is "You need setAlertLabelText"
/*文字大小*/
@property (strong,nonatomic) UIFont *alertLabelFont; //default  14
/*文字颜色*/
@property (strong,nonatomic) UIColor *alertLabelColor;  //default kCOLOR(151, 255, 255);
/*确认标题*/
@property (strong,nonatomic) NSArray *alertLabelBtnTitle;//default @[@"确认"];
/*确认按钮颜色*/
@property (strong,nonatomic) NSArray *alertLabelBtnColor; //defult @[kCOLOR(151,255,255)]
/*确认按钮标题颜色*/
@property (strong,nonatomic) NSArray *alertLabelBtnTitleColor; //defult @[[UIColor white]]


#pragma mark - ======================popViewShowAndHide======================
- (void)showPopView;
/*从哪一点显示出来*/
@property (assign,nonatomic) CGPoint showPoint;

- (void)hidenPopView;
@end
