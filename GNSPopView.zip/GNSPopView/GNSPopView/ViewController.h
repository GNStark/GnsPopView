//
//  ViewController.h
//  GNSPopView
//
//  Created by Lyn on 2017/6/8.
//  Copyright © 2017年 Lyn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

