//
//  ViewController.m
//  GNSPopView
//
//  Created by Lyn on 2017/6/8.
//  Copyright © 2017年 Lyn. All rights reserved.
//

#import "ViewController.h"
#import "GNSPopView.h"

@interface ViewController () <GNSPopViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *firstBtn;
@property (weak, nonatomic) IBOutlet UIButton *seconBtn;
@property (weak, nonatomic) IBOutlet UIButton *thirdBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.firstBtn addTarget:self action:@selector(showPopView:) forControlEvents:UIControlEventTouchUpInside];
    [self.seconBtn addTarget:self action:@selector(showPopView:) forControlEvents:UIControlEventTouchUpInside];
    [self.thirdBtn addTarget:self action:@selector(showPopView:) forControlEvents:UIControlEventTouchUpInside];

}

- (void)showPopView :(UIButton *)btn {
    if(btn.tag == 0) {
        
        GNSPopView *popView = [[GNSPopView alloc]initWithFrame:CGRectMake(100,150, 200, 300) WithType:tableViewPopView];
        popView.showPoint = CGPointMake(300, 400);
        popView.popViewDelegate = self;
//        popView.tableDataArray = @[@"asdas",@"asdad",@"zxcxzc",@"sad"];
        [popView showPopView];
        
    }else if(btn.tag == 1) {
        
        GNSPopView *popView = [[GNSPopView alloc]initWithFrame:CGRectMake(100,150, 200, 20) WithType:alertPopView];
//        popView.showPoint = CGPointMake(0, 0);
        popView.popViewDelegate = self;
        //popView.alertLabelText = @"message,message,message,message";
        //popView.alertLabelFont = [UIFont systemFontOfSize:28];
        //popView.alertLabelColor = [UIColor redColor];
//        popView.alertLabelBtnTitle =@[@"ClickMe1",@"ClickMe2"];
//        popView.alertLabelBtnColor = @[[UIColor redColor],[UIColor blackColor]]; //defult @[kCOLOR(151,255,255)]
//        popView.alertLabelBtnTitleColor = @[[UIColor whiteColor],[UIColor redColor]]; 
        [popView showPopView];
    }else {
        GNSPopView *popView = [[GNSPopView alloc]initWithFrame:CGRectMake(100,20, 200, 300) WithType:textViewPopView];
        popView.showPoint = CGPointMake(500, 600);
        popView.popViewDelegate = self;
//        popView.textViewFont = [UIFont systemFontOfSize:15];
//        popView.textSureBtnColor = [UIColor redColor];
//        popView.textSureBtnTitle = @"clickMe";
//        popView.textSureBtnTitleColor = [UIColor blackColor];
        [popView showPopView];

    }
}
- (void)textViewBtnClick:(NSString *)text {
    NSLog(@"%@",text);
}
- (void)alertBtnClick:(UIButton *)btn {
    NSLog(@"%@",btn);
}
- (void)popTableViewDidSelect:(NSIndexPath *)index {
    NSLog(@"%@",index);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
